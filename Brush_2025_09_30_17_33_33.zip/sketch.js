function setup() {
  createCanvas(600, 400);
  background(10, 20, 40); // Deep night blue background
  colorMode(HSB, 360, 100, 100, 1); // Use HSB for easier hue jitter
  noStroke();
}

function draw() {
  // By drawing a semi-transparent background each frame,
  // we can create a fading trail effect for the brush strokes.
  background(10, 20, 40, 0.1);
}

// This function is called automatically whenever the mouse is moved
// while a mouse button is pressed.
function mouseDragged() {
  // --- Brush Dynamics ---
  // Calculate the speed of the mouse movement.
  let speed = dist(mouseX, mouseY, pmouseX, pmouseY);
  
  // Map the speed to the size of the brush stamp.
  // Faster movement = smaller stamp.
  let size = map(speed, 0, 20, 30, 10, true);

  // --- Draw the Brush Stamp ---
  // Call our custom function to draw the peacock eye at the mouse position.
  drawPeacockEye(mouseX, mouseY, size);
}

/**
 * Draws a single "stamp" of the Peacock's Eye brush.
 * @param {number} x The center x-coordinate.
 * @param {number} y The center y-coordinate.
 * @param {number} size The diameter of the main eye pattern.
 */
function drawPeacockEye(x, y, size) {
  
  // --- Iridescence Effect ---
  // Add a small random value to the hue of each color to make it shimmer.
  let hueJitter = random(-10, 10);

  // --- Draw Concentric Circles ---
  
  // Outer Layer (Green/Teal)
  // This layer is more transparent.
  fill(180 + hueJitter, 80, 70, 0.5);
  ellipse(x, y, size, size);

  // Middle Layer (Gold)
  fill(50 + hueJitter, 90, 90, 0.8);
  ellipse(x, y, size * 0.7, size * 0.7);

  // Inner Layer (Deep Blue/Purple)
  fill(260 + hueJitter, 85, 60, 1);
  ellipse(x, y, size * 0.35, size * 0.35);
}

// Add a welcome message or instruction.
function mousePressed() {
  // Clear the canvas when the user clicks for a fresh start.
  background(10, 20, 40);
}